package com.gmm.base.rest;

import org.springframework.web.bind.annotation.*;

@RestController
public class APICountController {
		
	@GetMapping(value = "/add")
	public String add(@RequestParam("x") int x,@RequestParam("y") int y){
		   return "<h2>The sum of "+x+" and "+y+" is "+(x+y)+"</h2>";
	   }
	   	
	@GetMapping(value = "/subtract")
	public String subtract(@RequestParam("x") int x,@RequestParam("y") int y){
		return "<h2>The difference between "+x+" and "+y+" is "+(x-y)+"</h2>";
	   }
	   
	@GetMapping( "/multiply")
	public String multiply(@RequestParam("x") int x,@RequestParam("y") int y){
		return "<h2>The product of "+x+" and "+y+" is "+(x*y)+"</h2>";
	   }
	   
	@GetMapping("/divide")
	public String divide(@RequestParam("x") int x,@RequestParam("y") int y){
		return "<h2>The quotient after dividing "+x+" with "+y+" is "+(x/y)+"</h2>";
	   }

	@PostMapping("/postingValue")
	public String successPost(){
		System.out.println("<-- Testing Post -->");
		return "<-- Successfully Stored -->";
	}
	
}
