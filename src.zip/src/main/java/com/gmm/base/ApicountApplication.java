package com.gmm.base;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApicountApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApicountApplication.class, args);
	}
}
